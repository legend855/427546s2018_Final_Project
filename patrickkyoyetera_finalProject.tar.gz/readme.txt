Author: Patrick Kyoyetera

Report


PROGRESS:
This week, I managed to implement isometric, dimetric and trimetric projections. I haven't been able to get trimetric to work perfectly but I hope I will do 
in the coming week. I also didn;'t get to accomplish the camera/views but this shouldn;t take more than a day;s work. I hope 
to have this all done in about a week. By the time the next presentations come around.
