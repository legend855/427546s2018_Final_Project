Author: Patrick Kyoyetera


These are the sources I have used iduring the implemenation of this project.


1. https://www.tutorialspoint.com/computer_graphics/3d_transformation.htm (for transformations)
2. https://workshop.chromeexperiments.com/examples/gui/  (for menu) 
3. https://threejs.org/docs/ (library used for all implemenation)
4. http://www.opengl-tutorial.org/beginners-tutorials/tutorial-3-matrices/ (Affine Matrix transformations)
5. http://www.euclideanspace.com/maths/geometry/affine/matrix4x4/ (More matrix stuff)

